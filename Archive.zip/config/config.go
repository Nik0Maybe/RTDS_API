package config

const ApiKey = "your-secure-api-key"
const BrokerAddress = "csqnjbdjp6ucv9qq9fi0.any.us-east-1.mpx.prd.cloud.redpanda.com:9092"

const RateLimitRequestsPerSecond = 5
const RateLimitBurst = 10
