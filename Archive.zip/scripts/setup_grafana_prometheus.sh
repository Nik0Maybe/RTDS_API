if ! command -v brew &> /dev/null; then
    echo "Homebrew not found. Please install Homebrew first from https://brew.sh/"
    exit 1
fi

echo "Installing Prometheus..."
brew install prometheus

echo "Installing Grafana..."
brew install grafana

PROMETHEUS_CONFIG_DIR="/usr/local/etc/prometheus" # Default config directory for Homebrew
mkdir -p "$PROMETHEUS_CONFIG_DIR"

echo "Configuring Prometheus..." 
cat << EOF > "$PROMETHEUS_CONFIG_DIR/prometheus.yml"
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: "golang_api"
    metrics_path: "/metrics"
    static_configs:
      - targets: ["localhost:8080"]
EOF

echo "Starting Prometheus..."
brew services start prometheus

echo "Starting Grafana..."
brew services start grafana

echo "Grafana is running. Access it at: http://localhost:3000"
echo "Default login - Username: admin, Password: admin (you will be prompted to change this on first login)"

echo "Prometheus is running and configured to scrape metrics from http://localhost:8080/metrics."
echo "Access Prometheus at: http://localhost:9090"

echo "Setup complete. Please log in to Grafana and add Prometheus as a data source."
