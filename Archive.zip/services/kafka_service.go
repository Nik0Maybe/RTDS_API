package services

import (
	"RTDS_API/config"
	"context"
	"crypto/tls"
	"log"

	"github.com/segmentio/kafka-go"
	"github.com/segmentio/kafka-go/sasl/scram"
)

var KafkaWriters = make(map[string]*kafka.Writer)

func InitKafkaProducer(brokerAddress, streamID string) error {
	if _, exists := KafkaWriters[streamID]; !exists {
		mechanism, err := scram.Mechanism(scram.SHA256, "Nik0maybe", "FJ57UxjIQFvdQRDNbH5XPQyqKEHMBr")
		if err != nil {
			return err
		}

		writer := &kafka.Writer{
			Addr:     kafka.TCP(brokerAddress),
			Topic:    "stream-topic",
			Balancer: &kafka.LeastBytes{},
			Transport: &kafka.Transport{
				TLS:  &tls.Config{},
				SASL: mechanism,
			},
		}

		KafkaWriters[streamID] = writer
	}
	return nil
}

func ProduceMessage(streamID, message string) error {
	writer, exists := KafkaWriters[streamID]
	if !exists {
		return InitKafkaProducer(config.BrokerAddress, streamID)
	}

	return writer.WriteMessages(context.Background(),
		kafka.Message{Key: []byte(streamID), Value: []byte(message)},
	)
}

func ConsumeMessages(streamID string, resultsChan chan<- string) {
	reader := kafka.NewReader(kafka.ReaderConfig{
		Brokers: []string{config.BrokerAddress},
		Topic:   "stream-topic",
		GroupID: "consumer-group-" + streamID,
	})

	defer reader.Close()
	for {
		msg, err := reader.ReadMessage(context.Background())
		if err != nil {
			log.Printf("Error reading message from Kafka: %v", err)
			continue
		}
		resultsChan <- "Processed: " + string(msg.Value)
	}
}
