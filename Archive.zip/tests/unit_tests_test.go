package tests

import (
	"errors"
	"testing"
)

var KafkaWriters = make(map[string]bool)

func InitKafkaProducer(broker string, streamID string) error {
	if broker == "" || streamID == "" {
		return errors.New("invalid broker or streamID")
	}
	KafkaWriters[streamID] = true
	return nil
}

func ProduceMessage(streamID string, message string) error {
	if _, exists := KafkaWriters[streamID]; !exists {
		return errors.New("kafka writer not initialized")
	}
	return nil
}

func TestProduceMessage(t *testing.T) {
	streamID := "test-stream"
	message := "test-message"

	if err := InitKafkaProducer("localhost:9092", streamID); err != nil {
		t.Fatalf("Failed to initialize Kafka producer: %v", err)
	}

	err := ProduceMessage(streamID, message)
	if err != nil {
		t.Errorf("Expected no error, got %v", err)
	}
}

func TestInitKafkaProducer(t *testing.T) {
	streamID := "test-stream-init"
	err := InitKafkaProducer("localhost:9092", streamID)

	if err != nil {
		t.Fatalf("InitKafkaProducer failed: %v", err)
	}
	if _, exists := KafkaWriters[streamID]; !exists {
		t.Errorf("Expected Kafka writer for streamID '%s' to be initialized", streamID)
	}
}
