package tests

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"RTDS_API/handlers"
)

func TestStartStreamHandler(t *testing.T) {
	req, err := http.NewRequest("POST", "/stream/start", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(handlers.StartStreamHandler)
	handler.ServeHTTP(rr, req)

	if status := rr.Code; status != http.StatusOK {
		t.Errorf("Handler returned wrong status code: got %v want %v", status, http.StatusOK)
	}
}
